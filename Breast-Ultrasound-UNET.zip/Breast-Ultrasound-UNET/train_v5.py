# train_v5_smp.py — U-Net with pretrained ResNet34 encoder (target 0.77–0.80 Dice)
import os, glob, csv, cv2, numpy as np
from tqdm import tqdm
from sklearn.model_selection import train_test_split

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader

import albumentations as A
import segmentation_models_pytorch as smp  # pip install segmentation-models-pytorch timm

# ---------------- Dataset ----------------
class BUSI(Dataset):
    def __init__(self, items, size=256, augment=False):
        self.items, self.size, self.augment = items, size, augment
        self.tf = A.Compose([
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.2),
            A.Rotate(limit=15, border_mode=cv2.BORDER_REFLECT_101, p=0.5),
            A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.10, rotate_limit=15, p=0.5),
            A.RandomBrightnessContrast(p=0.35),
        ]) if augment else None

    def __len__(self): return len(self.items)
    def __getitem__(self, i):
        ip, mp = self.items[i]
        img = cv2.imread(ip, cv2.IMREAD_GRAYSCALE)
        msk = cv2.imread(mp, cv2.IMREAD_GRAYSCALE)

        img = cv2.resize(img, (self.size, self.size))
        msk = cv2.resize(msk, (self.size, self.size))

        if self.tf:
            out = self.tf(image=img, mask=msk)
            img, msk = out["image"], out["mask"]

        # grayscale -> 1 channel
        img = (img.astype(np.float32) / 255.0)[None, ...]   # [1,H,W]
        msk = (msk.astype(np.float32) / 255.0)[None, ...]   # [1,H,W]
        return torch.from_numpy(img), torch.from_numpy(msk)

# ---------------- Loss & metric ----------------
class DiceLoss(nn.Module):
    def forward(self, logits, y):
        p = torch.sigmoid(logits)
        inter = (p*y).sum(dim=(1,2,3))
        den   = p.sum(dim=(1,2,3)) + y.sum(dim=(1,2,3))
        return 1 - ((2*inter+1e-6)/(den+1e-6)).mean()

def bce_dice_loss(logits, y, w_bce=0.3, w_dice=0.7):
    bce  = nn.BCEWithLogitsLoss()(logits, y)
    dice = DiceLoss()(logits, y)
    return w_bce*bce + w_dice*dice

@torch.no_grad()
def dice_metric(probs, y, thr=0.5):
    pred  = (probs > thr).float()
    inter = (pred*y).sum(dim=(1,2,3))
    union = pred.sum(dim=(1,2,3)) + y.sum(dim=(1,2,3))
    return ((2*inter+1e-6)/(union+1e-6)).mean()

# ---------------- Train ----------------
def train():
    DATA_ROOT = os.path.join("Data","Dataset_BUSI_with_GT")

    # pair images with *_mask
    pairs = []
    for ext in ("*.png","*.jpg","*.jpeg"):
        for p in glob.glob(os.path.join(DATA_ROOT,"**",ext), recursive=True):
            if "_mask" in p.lower(): continue
            base,_ = os.path.splitext(p)
            for mext in (".png",".jpg",".jpeg"):
                m = base + "_mask" + mext
                if os.path.exists(m):
                    pairs.append((p,m)); break

    tr, va = train_test_split(pairs, test_size=0.2, random_state=42)

    # DataLoaders (adjust num_workers if CPU is slow)
    train_dl = DataLoader(BUSI(tr,256,augment=True),  batch_size=8, shuffle=True,
                          num_workers=4, pin_memory=True, persistent_workers=True)
    val_dl   = DataLoader(BUSI(va,256,augment=False), batch_size=8, shuffle=False,
                          num_workers=4, pin_memory=True, persistent_workers=True)

    device = "cuda" if torch.cuda.is_available() else "cpu"

    # U-Net with ResNet34 encoder, pretrained on ImageNet
    model = smp.Unet(
        encoder_name="resnet34",
        encoder_weights="imagenet",
        in_channels=1,      # grayscale
        classes=1           # binary mask (logits)
    ).to(device)

    opt = optim.AdamW(model.parameters(), lr=2e-4, weight_decay=1e-5)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(opt, mode="max", factor=0.5, patience=5)

    os.makedirs("runs_v5", exist_ok=True)
    log_csv = os.path.join("runs_v5", "train_log.csv")
    with open(log_csv, "w", newline="") as f:
        csv.writer(f).writerow(["epoch","val_dice","train_loss","lr"])

    # Early stopping
    best = 0.0
    patience = 0
    PATIENCE_LIMIT = 12
    MIN_DELTA = 0.005

    EPOCHS = 40  # hard cap
    scaler = torch.cuda.amp.GradScaler(enabled=(device=="cuda"))

    for ep in range(1, EPOCHS+1):
        # ---- train
        model.train()
        train_losses = []
        pbar = tqdm(train_dl, desc=f"Epoch {ep}/{EPOCHS}", leave=False)
        for x,y in pbar:
            x = x.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)
            opt.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=(device=="cuda")):
                logits = model(x)
                loss   = bce_dice_loss(logits,y, w_bce=0.3, w_dice=0.7)
            scaler.scale(loss).backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(opt)
            scaler.update()
            train_losses.append(loss.item())
            pbar.set_postfix(loss=f"{loss.item():.4f}")

        # ---- validate (with simple TTA: horizontal flip)
        model.eval(); dices=[]
        with torch.no_grad():
            for x,y in val_dl:
                x = x.to(device, non_blocking=True)
                y = y.to(device, non_blocking=True)
                # TTA avg
                logits1 = model(x)
                logits2 = model(torch.flip(x, dims=[3]))
                logits2 = torch.flip(logits2, dims=[3])
                probs = torch.sigmoid(0.5*(logits1 + logits2))
                dices.append(dice_metric(probs,y,thr=0.5).item())

        md = float(np.mean(dices))
        tl = float(np.mean(train_losses))
        lr = opt.param_groups[0]["lr"]
        print(f"[VAL] Dice={md:.4f} | TrainLoss={tl:.4f} | LR={lr:.2e}")
        scheduler.step(md)

        with open(log_csv, "a", newline="") as f:
            csv.writer(f).writerow([ep, f"{md:.4f}", f"{tl:.4f}", f"{lr:.2e}"])

        # save + early stop on meaningful gain
        if md > best + MIN_DELTA:
            best = md; patience = 0
            torch.save(model.state_dict(),"runs_v5/unet_resnet34_best.pth")
            print(f"saved best model -> Dice {best:.4f}")
        else:
            patience += 1
            if patience >= PATIENCE_LIMIT:
                print("Early stopping! No significant Dice improvement.")
                break

    print(f"BEST Dice={best:.4f}")

if __name__ == "__main__":
    train()
