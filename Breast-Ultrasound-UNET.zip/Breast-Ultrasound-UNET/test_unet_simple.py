# test_v5_infer.py  — minimal, ready-to-run tester for v5 (ResNet34 U-Net)

import os, glob, cv2, numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
import segmentation_models_pytorch as smp  # pip install segmentation-models-pytorch timm

# --------- SETTINGS (edit if needed) ----------
data_root  = os.path.join("Data", "Dataset_BUSI_with_GT")
ckpt_path  = os.path.join("runs_v5", "unet_resnet34_best.pth")  # your v5 checkpoint
img_size   = 256                  # must match training
batch_size = 8
num_vis    = 12                   # how many images to save for the report
use_tta    = True                 # horizontal flip TTA
outdir     = "runs_v5_test"
seed       = 42
# ---------------------------------------------

os.makedirs(outdir, exist_ok=True)
vis_dir = os.path.join(outdir, "vis")
os.makedirs(vis_dir, exist_ok=True)

# --------- Dataset ---------
class BUSI(Dataset):
    def __init__(self, items, size=256):
        self.items, self.size = items, size
    def __len__(self): return len(self.items)
    def __getitem__(self, i):
        ip, mp = self.items[i]
        img = cv2.imread(ip, cv2.IMREAD_GRAYSCALE)
        msk = cv2.imread(mp, cv2.IMREAD_GRAYSCALE)
        img = cv2.resize(img, (self.size, self.size))
        msk = cv2.resize(msk, (self.size, self.size))
        img = (img.astype(np.float32) / 255.0)[None, ...]
        msk = (msk.astype(np.float32) / 255.0)[None, ...]
        return torch.from_numpy(img), torch.from_numpy(msk), os.path.basename(ip)

# --------- Utilities ---------
@torch.no_grad()
def dice_from_probs(probs, y, thr):
    pred  = (probs > thr).float()
    inter = (pred*y).sum(dim=(1,2,3))
    union = pred.sum(dim=(1,2,3)) + y.sum(dim=(1,2,3))
    return ((2*inter+1e-6)/(union+1e-6))

@torch.no_grad()
def predict(model, x, tta=False):
    logits = model(x)
    if tta:
        logits2 = model(torch.flip(x, dims=[3]))
        logits  = 0.5*(logits + torch.flip(logits2, dims=[3]))
    return torch.sigmoid(logits)

# --------- Build test list (70/15/15 split-ish, stable seed) ---------
rng = np.random.RandomState(seed)
pairs = []
for ext in ("*.png", "*.jpg", "*.jpeg"):
    for p in glob.glob(os.path.join(data_root, "**", ext), recursive=True):
        if "_mask" in p.lower(): 
            continue
        base, _ = os.path.splitext(p)
        for mext in (".png", ".jpg", ".jpeg"):
            m = base + "_mask" + mext
            if os.path.exists(m):
                pairs.append((p, m)); break

pairs = np.array(pairs)
rng.shuffle(pairs)
n = len(pairs)
n_train = int(0.70*n)
n_val   = int(0.15*n)
train_pairs = pairs[:n_train]
val_pairs   = pairs[n_train:n_train+n_val]
test_pairs  = pairs[n_train+n_val:]

test_ds = BUSI(test_pairs.tolist(), img_size)
test_dl = DataLoader(test_ds, batch_size=batch_size, shuffle=False)

# --------- Load model (must match v5 architecture) ---------
device = "cuda" if torch.cuda.is_available() else "cpu"
model = smp.Unet(
    encoder_name="resnet34",
    encoder_weights=None,   # weights are in the checkpoint
    in_channels=1,
    classes=1
).to(device)

sd = torch.load(ckpt_path, map_location=device)
model.load_state_dict(sd, strict=True)
model.eval()

# --------- Threshold sweep on test set ---------
thrs = np.linspace(0.30, 0.70, 9)  # 0.30, 0.35, ..., 0.70
all_probs, all_gt = [], []
with torch.no_grad():
    for x, y, _ in test_dl:
        x = x.to(device); y = y.to(device)
        probs = predict(model, x, tta=use_tta)
        all_probs.append(probs.cpu()); all_gt.append(y.cpu())

all_probs = torch.cat(all_probs, dim=0)
all_gt    = torch.cat(all_gt, dim=0)

dice_list = [dice_from_probs(all_probs, all_gt, float(t)).mean().item() for t in thrs]
best_idx  = int(np.argmax(dice_list))
best_thr  = float(thrs[best_idx])
best_dice = float(dice_list[best_idx])

with open(os.path.join(outdir, "metrics.txt"), "w") as f:
    f.write(f"Test images: {len(test_ds)}\n")
    f.write(f"Best threshold: {best_thr:.3f}\n")
    f.write(f"Test Dice @ best thr: {best_dice:.4f}\n")
    f.write("Sweep:\n")
    for t, d in zip(thrs, dice_list):
        f.write(f"  thr={t:.2f} -> Dice={d:.4f}\n")

print(f"[TEST] Best thr={best_thr:.3f} | Dice={best_dice:.4f}")
print(f"Saved metrics to {os.path.join(outdir, 'metrics.txt')}")

# --------- Save a few visualizations ---------
vis_count = min(num_vis, len(test_ds))
vis_loader = DataLoader(BUSI(test_pairs[:vis_count].tolist(), img_size), batch_size=1, shuffle=False)

for i, (x, y, name) in enumerate(vis_loader):
    x = x.to(device); y = y.to(device)
    probs = predict(model, x, tta=use_tta)
    pred  = (probs > best_thr).float()

    img  = x[0,0].cpu().numpy()
    gt   = y[0,0].cpu().numpy()
    pd   = pred[0,0].cpu().numpy()

    plt.figure(figsize=(10,3.2))
    plt.subplot(1,3,1); plt.imshow(img, cmap="gray"); plt.title("Input"); plt.axis("off")
    plt.subplot(1,3,2); plt.imshow(gt,  cmap="gray"); plt.title("Ground Truth"); plt.axis("off")
    plt.subplot(1,3,3); plt.imshow(img, cmap="gray"); plt.imshow(pd, cmap="jet", alpha=0.35)
    plt.title("Prediction"); plt.axis("off")
    plt.tight_layout()
    out_png = os.path.join(vis_dir, f"{i:02d}_{os.path.splitext(name[0])[0]}.png")
    plt.savefig(out_png, dpi=150); plt.close()

print(f"✅ Done. Check '{outdir}\\metrics.txt' and '{vis_dir}\\*.png'")
