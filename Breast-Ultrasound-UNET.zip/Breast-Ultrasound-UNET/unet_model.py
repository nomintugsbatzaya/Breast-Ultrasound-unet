import torch
import torch.nn as nn #imports necessary neural network toolbox
import torch.nn.functional as nnfunc 

class DoubleConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DoubleConv, self).__init__()
        self.double_conv = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1), #first convolution
                nn.BatchNorm2d(out_channels),
                #batch norm will help normalise the effects of activation functions
                #so that the model will be more stable and fast as per Geek4Geeks.
                nn.ReLU(inplace=True), # <- the activation function
                nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True)
    )
    
    def forward(self, tensor):

        return self.double_conv(tensor)
    


class UNET(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(UNET, self).__init__() 
        '''a super(x).__init__() is necessary to initialise
        the base nn.Module so that dependencies and everything
        works for neural networks in pytorch
        Args:
        in_channel= number of input channels, 1 for grayscale
        out_channels = number of output channels, 1 for binary segmentation
        the unet paper has the following decoder implementaiton:
        1) x2 double conv
        2)max pool 2x2
        3) x2 double conv
        4)max pool 2x2
        5) x2 double conv
        6) maxpool 2x2
        7) x2 double conv
        8) max pool 2x2
        9) x2 double conv
        using this, there are 5 **diferent** double conv operations
        but there's only 1 max pool operation, because the double conv
        has to accoutn for changes in dimension'''
        self.max_pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.dconv1 = DoubleConv(in_channels, 64) #1 input, 64 output as per UNET paper
        self.dconv2 = DoubleConv(64, 128)
        self.dconv3 = DoubleConv(128, 256)
        self.dconv4 = DoubleConv(256, 512)
        self.dconv5 = DoubleConv(512, 1024)
        
        '''these are the variables for the decoder
        upsampling is the opposite of max pooling'''
        self.upsample4 = nn.ConvTranspose2d(1024, 512, kernel_size=2, stride=2)
        self.upconv4 = DoubleConv(1024,512)
        
        self.upsample3 = nn.ConvTranspose2d(512, 256, kernel_size=2, stride=2)
        self.upconv3 = DoubleConv(512,256)
        
        self.upsample2 = nn.ConvTranspose2d(256, 128, kernel_size=2, stride=2)
        self.upconv2 = DoubleConv(256, 128)
        
        self.upsample1 = nn.ConvTranspose2d(128, 64, kernel_size=2, stride=2)
        self.upconv1 = DoubleConv(128, 64)
        
        '''after this the last step is one final 1x1 conv layer'''
        self.outconv = nn.Conv2d(64,1, kernel_size=1)
    
    def _concat(self, up_tensor, skip_tensor):
        if up_tensor.size(2) != skip_tensor.size(2) or up_tensor.size(3) != skip_tensor.size(3):
            # Calculate differences in H and W
            y_ax_diff = skip_tensor.size(2) - up_tensor.size(2)  # height diff
            x_ax_diff = skip_tensor.size(3) - up_tensor.size(3)  # width diff

            # Pad order in F.pad = [left, right, top, bottom]
            up_tensor = nnfunc.pad(
                up_tensor,
                [x_ax_diff // 2, x_ax_diff - x_ax_diff // 2,   #[left, right
                y_ax_diff // 2, y_ax_diff - y_ax_diff // 2]  # top, bottom]
            )
        # Concatenate along channel dimension note [batch, channel, height, width]
        return torch.cat([skip_tensor, up_tensor], dim=1)
        
        
    
    
    def forward(self, tensor):
        #steps 1-9 are the encoder portion of UNET
        step1 = self.dconv1(tensor) #
        step2 = self.max_pool(step1)
        step3 = self.dconv2(step2) #
        step4 = self.max_pool(step3)
        step5 = self.dconv3(step4) #
        step6 = self.max_pool(step5)
        step7 = self.dconv4(step6) #
        step8 = self.max_pool(step7)
        step9 = self.dconv5(step8) 
        #the steps below are for the decoder portion
        step10 = self.upsample4(step9)
        step11 = self._concat(step10, step7)
        step12 = self.upconv4(step11)

        # level 3: up 512->256, concat with step5 (256), then conv to 256
        step13 = self.upsample3(step12)
        step14 = self._concat(step13, step5)
        step15 = self.upconv3(step14)

        # level 2: up 256->128, concat with step3 (128), then conv to 128
        step16 = self.upsample2(step15)
        step17 = self._concat(step16, step3)
        step18 = self.upconv2(step17)

        # level 1: up 128->64, concat with step1 (64), then conv to 64
        step19 = self.upsample1(step18)
        step20 = self._concat(step19, step1)
        step21 = self.upconv1(step20)

        # output logits -- which are the raw outputs of NNs
        return self.outconv(step21)